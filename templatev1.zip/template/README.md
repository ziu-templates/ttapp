## {{ name }}
----------------------------
author: {{ author }} <br>
description: {{ description }}

<br>
###配置说明：
<br>
####1. ./docs --- 项目文档<br>

开发
====
appid：<br>

接口
====
[接口文档](./docs/api.md)
