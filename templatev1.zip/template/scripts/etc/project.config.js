module.exports = {
  miniprogramRoot: '.',
  setting: {
    urlCheck: true,
    es6: true,
    minified: true,
    postcss: true,
    uglifyFileName: true,
    newFeature: true,
    nodeModules: true,
    autoAudits: false,
    uglifyFileName: true
  }
};