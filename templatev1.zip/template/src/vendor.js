
module.exports = {
    env: process.env.PRJ_ENV
};